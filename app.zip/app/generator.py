# app/generator.py
import random
import string

def personalized_password(answers):
    # Example answers: {'color': 'blue', 'animal': 'panda', 'year': '2031', 'symbol': '@'}
    base = f"{answers['color'].capitalize()}{answers['animal'].capitalize()}{answers['year']}{answers['symbol']}"
    # Add some randomness for entropy
    extra = ''.join(random.choices(string.ascii_letters + string.digits, k=2))
    return base + extra

if __name__ == "__main__":
    answers = {
        "color": "blue",
        "animal": "Panda",
        "year": "2031",
        "symbol": "@"
    }
    print("Generated Password:", personalized_password(answers))
